### Language Evolution Simulation with ABMs

Just for fun.

Demo:

<https://fatiherikli.github.io/language-evolution-simulation>

Agent based models on wikipedia:

<https://www.wikiwand.com/en/Agent-based_model>

